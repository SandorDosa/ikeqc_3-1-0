<?php
$vars_start = get_defined_vars();
session_start();
include "year.inc";
include "ikeqcfuncs.inc";
include "colors.inc";

IF (isset($PName)) {

    $EC = NameTest($PName);
    
    $PNT = substr($PName, 0, 5)."%";
    $PCT = "%".substr($Pcka, 0, 5)."%";
    $PAT = "%".substr($Paka, 0, 5)."%";
    $PMT = substr($Pmka, 0, 5)."%";
    $PSDXT = soundex($PName);
    
    
    $seta = mysql_query("SELECT PID,PName,Pcka,Paka,Pmka,PSdx FROM riders WHERE (PName LIKE '$PNT' OR Pcka LIKE '$PNT' OR Paka LIKE '$PNT' OR Pcka LIKE '$PNT' OR Pcka LIKE '$PCT' OR Pcka LIKE '$PAT' OR Paka LIKE '$PNT' OR Paka LIKE '$PCT' OR Paka LIKE '$PAT' OR Pmka LIKE '$PMT' OR PSdx LIKE '$PSDXT') ORDER BY PID", $db);
    IF ($A = mysql_fetch_array($seta)) {
        IF (mysql_num_rows($A) > 0) {
            // TODO Dupe name routine
        }
    }
    
    IF (isset($Review) AND $Review < 0) {
        unset($Review);
        header('Location: '.$_SERVER['PHP_SELF'].'?PName=$PName&Pcka=$Pcka&Paka=$Paka&Pmka=$Pmka&PHonors=$PHonors&PPhone=$PPhone&PEmail=$PEmail&PBio=$PBio&trash=1');
    }
    include "new_rider.inc";
}



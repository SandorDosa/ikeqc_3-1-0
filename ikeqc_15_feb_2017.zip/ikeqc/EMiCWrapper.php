<?php
/**
 * Created by PhpStorm.
 * User: Bravo
 * Date: 1/26/17
 * Time: 6:05 PM
 */
// EMiCs ON-The-Field helper and scores input script
// TOTF.php
// v0.01
// Sandor Dosa
// Set ECHO Event lookup
// Set ROMEO Riders Lookup


include "year.inc";
include "colors.inc";
include "ikeqcfuncs.inc";
$vars_start = get_defined_vars();
session_start();

IF (!isset($_SESSION['EID']) OR $_SESSION['EID'] <= 0) {

    IF ($Ein == 999 AND $Eout == 0) {
        unset($Ein);
        unset($Eout);
        header('Location: '.$_SERVER['PHP_SELF']);
        die;
    }

    IF (!isset($Ein)) {
        $sete = mysql_query("SELECT * FROM events WHERE Estatus = 'O'");
        IF ($E = mysql_fetch_array($sete)) {
            print "<!DOCTYPE html>\n";
            print "<html>\n";
            print "<title>Events</title>\n";
            print "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n";
            print "<link rel=\"stylesheet\" href=\"http://www.w3schools.com/lib/w3.css\">\n";

            print "<header class=\"w3-panel\">\n";
            print "<H1>Welcome EMiC:</H1>\n";
            print "</header>\n";
            
            print "<section class=\"w3-panel\">\n";
            print "<P>The following events can be managed:</P>\n";
            print "<form class=\"w3-container\" method=\"post\" action=\"{$_SERVER['PHP_SELF']}\">\n";
            print "<SELECT NAME=\"Ein\">\n";
            do {
                printf("<OPTION VALUE=\"%s\">%s\n", $E[0], $E[2]);
            } while ($E = mysql_fetch_row($sete));
            print "</SELECT>\n<BR>\n";
            print "<P><button class=\"w3-btn w3-green\" name=\"EMiC\">Select Event</button>\n";
            print "</form></section>\n";
            die;
        } ELSE {
            printf("Something went wrong, click <A HREF=\"%s?\">here</A> to try again.\n", $_SERVER['PHP_SELF']);
            print "<PRE>";
            print_r($_POST);
            die(mysql_error());
        }
        
    }

    IF ($Ein > 0) {
        $_SESSION['EID'] = $Ein;
        $setee = mysql_query("SELECT * FROM events WHERE PID=$Ein", $db);
        IF ($EE = mysql_fetch_array($setee)) {
            $_SESSION['EID'] = $EE[0];
            $_SESSION['EName'] = $EE[2];
            $_SESSION['EPass'] = $EE[3];
            $_SESSION['EAdmin'] = $EE[4];
            $_SESSION['EAphone'] = $EE[5];
            $_SESSION['EAemail'] = $EE[6];
            $_SESSION['EH'] = $EE[11];
            $_SESSION['ER'] = $EE[12];
            $_SESSION['ED'] = $EE[13];
            $_SESSION['EM'] = $EE[14];
            $_SESSION['EB'] = $EE[15];
            $_SESSION['Estatus'] = $EE[18];
            header('Location: '.$_SERVER['PHP_SELF']);
            die;
        }
    }
}

// $_SESSION['EID'] Is set if the script gets this far

IF ($_SESSION['EID'] > 0) {

    IF (!isset($_SESSION['stats']) OR $_SESSION['stats'] <= 0) {
        $setr = mysql_query("SELECT PID,EH,ER,ED,EM,EB FROM events_temp WHERE EID={$_SESSION['EID']} AND Erun = 'N'", $db);
        IF ($R = mysql_fetch_array($setr)) {
            $EP = mysql_num_rows($setr);
            do {
                IF ($_SESSION['EH'] == 'Y' AND $R[1] == 'Y') {
                    $EH++;
                }
                IF ($_SESSION['ER'] == 'Y' AND $R[2] == 'Y') {
                    $ER++;
                }
                IF ($_SESSION['ED'] == 'Y' AND $R[3] == 'Y') {
                    $ED++;
                }
                IF ($_SESSION['EM'] == 'Y' AND $R[4] == 'Y') {
                    $EM++;
                }
                IF ($_SESSION['EB'] == 'Y' AND $R[5] == 'Y') {
                    $EB++;
                }
            } while ($R = mysql_fetch_array($setr));
        }
        $_SESSION['stats'] = $_SESSION['EID'];
        $_SESSION['EPcount'] = $EP;
        IF (isset($EH)) {
            $_SESSION['EHcount'] = $EH;
        }
        IF (isset($ER)) {
            $_SESSION['ERcount'] = $ER;
        }
        IF (isset($ED)) {
            $_SESSION['EDcount'] = $ED;
        }
        IF (isset($EM)) {
            $_SESSION['EMcount'] = $EM;
        }
        IF (isset($EB)) {

            $_SESSION['EBcount'] = $EB;
        }

    }

    // The stats have been collected.
}

// By this point, the script knows what event, and what games in that ef